The ide/jhs addon is the JHS IDE for J7.

