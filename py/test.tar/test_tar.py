if __name__ == '__main__':
    print 'the rain in Spain falls mainly on the plane'

