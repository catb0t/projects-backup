# header
ax = 0x656
try:
    import head;
    from head import *;

    header()
except ImportError:
    from random import *


def zx():
    while 1: print(chr(randint(0, ax)), end='')
    zx()


# end


#
# to the reader: the following Read-Eval-Print-Loops and their children were built from the frontend to the back.
# the REPLS in head.py were built backend-first, thus they merely provide a realtime UI to the associated maths.
# these, however, outsource very little.
# as such, you may find their design more complex and less robust than other such REPLS.
#
# had the development of this program been backend-driven, it would be twice as good and twice as long.
# a given repl would consist of the frontend and back; here, the backend and output are mostly one in the same: the deepest nest level.
# this would cause the interface to be faster and less bloated, easier to maintain, and far smaller meaning fewer holes needing patching.
#
# the list comprehensions needed herein should probably be done with map(), zip() and lambdas but I don't understand those well enough yet to implement them.
# should also probably use yield in said lists rather than... whatever you wanna call the bullshit we are using.
#

def rnd(var):  # round to two places, rounding down in the process, then round up. needed for tip calculation.
    vsplit = sr(var).split(dt, 2)  # split the string on the .
    rav = flt(vsplit[0] + dt + vsplit[1][:2]) + .01  # glue it back, round it up and turn it to a float
    rsplit = sr(rav).split(dt, 2)  # split it again
    return flt(rsplit[0] + dt + rsplit[1][:2])  # trim all but two decimal places and glue it back


def unrnd(var):  # fix a bug caused by rnd(x) which results in +1c of change,interest from nowhere and 32 F = 0.01 C
    return sr(float(var) - .01)  # undo the +0.01 by rnd which is really annoying but needed, sometimes


def toCoin(totl):
    totl = unrnd(rnd(sr(totl)))
    total = totl
    tsplit = sr(totl).split(dt, 2)  # split the string on the . -> array
    # dolladolla
    totl = flt(tsplit[0])
    tw = totl // 20
    totl %= 20
    tn = totl // 10
    totl %= 10
    fv = totl // 5
    totl %= 5
    on = totl
    # pocket change tbh
    totl = flt(tsplit[1])
    hd = totl // 50
    totl %= 50
    qw = totl // 25
    totl %= 25
    dm = totl // 10
    totl %= 10
    ni = totl // 5
    totl %= 5
    pn = totl
    desc = [' twent', ' ten', ' five', ' one', ' half-dollar', ' quarter', ' dime', ' nickel', ' penn']  # info
    totl = [tw, tn, fv, on, hd, qw, dm, ni, pn]  # values
    prnt = ''  # empty string
    for i in xr(l(totl)):  # iterate over them to remove the '.0' for float()
        totl[i] = int(totl[i])

    for i in xr(l(totl)):  # iterate over them again, this time...
        string = sr(totl[i]) + desc[i]  # starter
        if totl[i] == 1:  # if singular...
            if i == 0 or i == 8:  # if 'odd'
                prnt += string + 'y' + nl  # add a y
            else:
                prnt += string + nl  # the other ones are singular already
        else:
            if i == 0 or i == 8:  # if plural and 'odd'...
                prnt += string + 'ies' + nl  # add an ies
            else:
                prnt += string + 's' + nl  # or an s

    w(nl + 'your change is:', total)  # print the change as a float
    w(prnt)  # then print the string we constructed.


def cvrt(tmp, uni, to):
    erstr = 'invalid conversion'  # duh.
    if uni == to: raise Val('conversion must not be of same unit!')  # that would be recursive.
    if type(tmp) != float: raise TypeError('temp must be float not',
                                           str(type(tmp)).split("'")[1] + ' !')  # str != float
    if uni == 'c':  # if centigrade
        if to == 'f':  # and farenheit
            # f = c * (9/5) + 32
            return tmp * (9 / 5) + 32
        elif to == 'k':
            # k = c - 273.15 = ((f - 32) * (5/9)) - 273.15
            return tmp - 273.15
        else:
            raise IO(erstr)  # why an Input/Output error for bad input? I don't know...
    elif uni == 'f':  # if f
        if to == 'c':  # and c
            # c = (f - 32) * (5/9)
            return (tmp - 32) * (5 / 9)
        elif to == 'k':
            # k = c - 273.15 = ((f - 32) * (5/9)) - 273.15
            return cvrt(tmp, 'f', 'c') - 273.15
        else:
            raise IO(erstr)
    elif uni == 'k':  # kelvins! that other, actually meaningful unit.
        if to == 'f':
            # k = c - 273.15 = ((f - 32) * (5/9)) - 273.15
            return cvrt(cvrt(tmp, 'k', 'c'), 'c', 'f')
        elif to == 'c':
            # k = c - 273.15 = ((f - 32) * (5/9)) - 273.15
            return tmp + 273.15
        else:
            raise IO(erstr)  # errors
    else:
        raise IO(erstr)  #


def getInterest():  # download and grep through a webpage for interest rates & rely on callee to catch errors
    # get the page text & put it in a var
    page = requests.get(
        'http://www.global-rates.com/interest-rates/central-banks/central-bank-america/fed-interest-rate.aspx')
    # turn it into actual html
    tree = html.fromstring(page.text)
    # use XPath to identify the tag holding the value
    rate = tree.xpath('//*[@id="lbl_centralebankpercentage"]/text()')
    # split it to get the number
    result = str(rate[0])[:5]  # 0.250&nbsp;% -> 0.250
    # make it a number
    return float(result)


def money():  # $$$
    try:
        interest = nl + sp + 'gur pheerag H.F. gpheerag vagrerfg engr vf: ' + str(getInterest()) + '%'
    except:
        interest = ''
    try:
        r('''
Gvc & Punatr Pnyphyngbe ERCY {}

[G]vc:
g fhogbgny gnk gvc -> gbgny
g   24.89   8  15  -> 31.85

[P]unatr:
p fhogbgny pnfu -> pnfu onpx
p  65.45   100  -> 34.55

[V]agrerfg:{}
v vavgvny engr ercrngf lrnef -> gbgny
v   100   .25    12      1   -> 128.07
v  24.89  .28    1       1   -> 31.86 '''.format('{', interest))  # docstrings? no.
        while 1:  # loop until kbint
            ip = sp.join(q(e('\n: ')).split()).lower().split(
                sp)  # get some input, then strip its extra whitespace and split it
            if l(ip) < 3:
                pass  # fail if the input is out of range
            else:  # if it's the right length...
                if ip[0] == 't' or ip[0] == 'c':  # what are we dealing with?
                    try:
                        n = t;mo, sl, mf = ip;ip = [mo, sl, mf, n]  # try to assign it
                    except Val:
                        mo = ip[0];n = t;sl = ip[1];mf = ip[2]  # if that fails, assign more robustly
                elif ip[0] == 'i':
                    try:
                        mo, sl, mf, x1, x2 = ip  # try to assign it
                    except Val:
                        mo = ip[0];sl = ip[1];mf = ip[2];x1 = ip[3];x2 = ip[
                            4]  # if that fails, assign more robustly
                try:
                    sl = flt(sl)  # try to convert to float
                    mf = flt(mf)  #
                    if mo == 'i':
                        x1 = flt(x1)  # interest specific
                        x2 = flt(x2)
                except Val:
                    ib()  # fail
                if mo == 't':  # repls r kool
                    tax = flt(mf * .01 + n);
                    food = sl  # total up the food
                    if tax >= 2:  # why the hell are you paying triple on tax?!?!
                        ib()  # that's a fail!
                    w('-> ' + sr(rnd(sr((food * tax) + food))))  # math.to_str
                elif mo == 'c':  # repls r kool
                    toCoin(mf - sl)
                elif mo == 'i':
                    #              P: principal amount (initial investment)
                    init = sl
                    #              r: annual nominal interest rate (as a decimal)
                    if mf:
                        interest = mf  # set it to a variable
                    else:
                        interest = .25  # fail (not sure how we got here if it wasn't set but yknow)
                    #              n: number of times the interest is compounded per year
                    repeat = x1
                    #              t: number of years
                    years = x2
                    # outsource nothing
                    w('-> ' + unrnd(sr(rnd(init * ((interest / repeat) + 1) ** (repeat * years)))))
                else:
                    ib()  # fail
    except KbInt:
        bc()  # handle CTRL-C nicely
    # though my testing, the next two can't be triggered by any input.
    # except Ind:ib() # if you somehow majorly mucked up your input, fail.
    # except: ib() # who knows what kind of junk the repl gets subjected to; just blame errors on the user.


def converTemp():
    try:
        r('''grzcrengher pbairefvba ERCY {

rkcyvpvg :
[sebz] [gb] [inyhr] -> inyhr
 S     P     32    -> 0P
 p     x     67    -> -206.13 K

be nyy :
[sebz] [inyhr0] -> u:inyhr1 u:inyhr2
 S      32    -> P:0 X:-273.15
 x      0     -> S:523.68 P:273.15''')  # NOT a docstring!!
        while 1:
            ip = sp.join(q(e('\n: ')).split()).lower().split(sp)  # split the input on spaces
            lip = l(ip)  # get the number of tokens
            ulist = ['f', 'c', 'k']  # make a list of units
            c = 'Pragvtenqr'  # this *is* a docstring... kinda.
            f = 'Sneraurvg / Prypvhf'
            k = 'Xryivaf'
            if lip == 2:  # if just two tokens,
                try:
                    su, tmp = ip  # try to makeuseof
                except Val:
                    ib()  # fail
                try:
                    tmp = flt(tmp)  # if the one that should be a number, isn't a number...
                except Val:
                    pass  # fail!
                if su in ulist:  # if it's in the list...
                    try:
                        ulist.remove(su)  # remove it!
                        # for some reason a generator / list comprehension didn't work here.
                        reslist = [cvrt(tmp, su, ulist[0]),
                                   cvrt(tmp, su, ulist[1])]  # list of results NOT including the input! clever, eh?
                        restr = '-> {}:{} {}:{}'.format(ulist[0], \
                                                        unrnd(rnd(reslist[0])), \
                                                        ulist[1], \
                                                        unrnd(rnd(reslist[1])))  # make it look nice
                        w(restr.upper())  # uppercase it, and print
                    except:
                        ib()  # fail!
                else:
                    ib()  # f a i l !
            elif lip == 3:  # if three tokens...
                try:
                    su, eu, tmp = ip  # try to iterate over them
                except Val:
                    ib()  # fail
                try:
                    tmp = flt(tmp)  # try to cast flt
                except Val:
                    ib()  # fail!
                try:
                    w('-> ' + unrnd(sr(rnd(cvrt(tmp, su, eu)))), eu.upper())  # evaluate it & print
                except:
                    ib()  # fail!
            elif lip == 1:
                if ip[0] == 'c':
                    r(c)  # docstrings...
                elif ip[0] == 'f':
                    r(f)  #
                elif ip[0] == 'k':
                    r(k)  #
                else:
                    pass  # some input should pass silently.
            else:
                pass  #
    except KbInt:
        bc()  # handling CTRL-C is important.


def distance():  # broken as HELL! (well, it *works* I just don't know what the garbage it returns is...)
    '''
 where dy is the lat. difference and dx is the long. difference
 Each degree of latitude (dy) is approx. 69 miles apart.
 At the 40th latitude, each degree of longitude (dx) is approx. 53 miles apart. (use this in your approximation)
 '''  # also, not a docstring.
    try:
        r('''
pbbeqvangrf-gb-qvfgnapr ERCY {
    k1,l1            k2,l2        -> xvybzrgerf :  zvyrf
42.3601,71.0589  37.7833,122.4167  ->  4384.33   : 2740.22
''')
        while 1:
            inp = sp.join(q(e('\n: ')).split()).lower().split(sp)
            if l(inp) == 2:
                x = inp[0].split(',')
                y = inp[1].split(',')
                x1 = flt(x[0]);
                y1 = flt(x[1])
                y2 = flt(y[0]);
                x2 = flt(y[1])
                dy = abs(y1 - y2)
                dx = abs(x1 - x2)
                w((((dy ** 2) + (dx ** 2)) ** .5) * 55)
            else:
                ib()
    except KbInt:
        bc()
    # this is probably completely broken because I don't understand the function ((dy**2)+(dx**2))**.5)
    # what does it actually return ? I don't know, and I don't care because it's 2am.


def madlib():  # lazy singular madlib. I wanted it to display on one line, which means change your shell's width, close it, reopen it, and rerun the program.
    try:
        u = '_'
        sh = '"{}!" ur fnvq {} nf ur whzcrq vagb uvf pbairegvoyr {} naq qebir bss jvgu uvf {} jvsr.{}'  # russian.

        inp = q(e(sh.format(u * 13, \
                            u * 8, \
                            u * 6, \
                            u * 11, \
                            nl + sp * 2 + 'rkpynzngvba' + sp * 13 + 'nqireo' + sp * 37 + 'abha' + sp * 26 + 'nqwrpgvir' + nl * 2) \
                  + '\n glcr jbeqf sbe gur fcnprf va gur beqre va juvpu gurl nccrne {\n : ')).split(' ')
        for i in xr(l(inp)):  # iterate over the input to ROT13 it
            inp[i] = e(inp[i])  #
        if l(inp) < 4:
            ib()  # fail on not enough input
        else:
            r(sh.format(inp[0], \
                        inp[1], \
                        inp[2], \
                        inp[3], \
                        nl))  # format strings are literal hell and I hate everything about them.
    except KbInt:
        bc()


def cvrtRepl():  # simple read-eval-print-loop conversion suite with plenty of functions
    qstring = '''\nGlcr gur pbeerfcbaqvat yrggre gb hfr n shapgvba be PGEY-P gb rkvg {
[V]agrerfg Pnyphyngbe
[G]enafnpgvbaf Pnyphyngbe
[P]baireg Grzcrengherf
[Q]vfgnapr Orgjrra Gjb Cbvagf
[Z]nqyvo Trarengbe (frg grezvany jvqgu > 200 !!)
['''  # also NOT a docstring. how do you make those again...? """ docstring """ ?
    while 1:
        try:
            f = q(e(qstring)).lower().split(' ')[0]
            if f == 'r':
                bc();r4e()  # i need my toolkit of REPLS handy.
            elif f == 'b':
                bc();rB64()  #
            elif f == 'h':
                bc();r();bo();printAttribLn();r();bc()  # r() without a string argument just prints a newline
            elif f == 'f':
                bc();rFib()  #
            elif f == 'zb':
                bc();printAttribLn(1);r();bc()  #
            elif f == 'i':
                bc();garbage(2000)  # tricked ya!
            elif f == 'g':
                bc();garbage()  # spits out garbage forever in small blocks.
            #
            elif f == 't':
                bc();money()  # choices, choices
            elif f == 'c':
                bc();converTemp()
            elif f == 'd':
                bc();distance()
            elif f == 'm':
                bc();madlib()
            elif f == 'zx':
                bc();zx()
            elif f == '':
                bc()  # read junk
            else:
                ib();bc()  # read more junk
        except KbInt:
            bc();break  # make CTRL-C prettier
        # except:r('\nshapgvba haqre pbafgehpgvba');bc();r()


if main.__file__ is __file__:
    cvrtRepl()
else:
    garbage()  # if calling this script from another file, spit out garbage forever.
